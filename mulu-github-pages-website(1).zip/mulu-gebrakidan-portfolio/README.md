# Mulu Gebrekidan Bezabih — Portfolio Website

A responsive, static HTML/CSS/JavaScript portfolio designed for GitHub Pages.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `mulu-portfolio`).
2. Upload `index.html` and the complete `assets` folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish the site. The public URL will appear in the Pages settings.

## Customize
- Edit `index.html` to update the profile, project descriptions, contact details or colors.
- Replace `assets/mulu-profile.jpeg` with an approved portrait, keeping the same filename or updating the image path in `index.html`.
- Check all project dimensions, role dates, qualifications and contact details before publishing.

## Privacy note
This portfolio intentionally omits date of birth, marital status, identity documents, certificates, recommendation letters and private reference contact details. Publish only information and images that the profile owner has approved for public access.
